// 结算
import React, { useEffect } from "react";

const PropertyRight = () => {

   useEffect( () => {
   },[])

   return (
      <>
         结算
      </>
   )
}

export default PropertyRight
// 打款情况
import React, { useEffect } from "react";

const PropertyRight = () => {

   useEffect( () => {
   },[])

   return (
      <>
         打款情况
      </>
   )
}

export default PropertyRight
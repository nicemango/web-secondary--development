// 装修附属
import React, { useEffect } from "react";

const PropertyRight = () => {

   useEffect( () => {
   },[])

   return (
      <>
         装修附属
      </>
   )
}

export default PropertyRight
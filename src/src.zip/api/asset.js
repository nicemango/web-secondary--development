import request from "./request";

/**
 * 查询资产(新的)
 * @param {*} params
 */
export const getAssets = (cata, type, params2) =>
  request.post(`asset/queryList?cata=${cata}&type=${type}`, params2);

/**
 * 查询资产
 */
export const queryAssetById = id =>
  request.post(`/asset/getAssetData?asset_id=${id}`, []);


/**
* 查询省份
*/
export const getProvinceArea = () =>
  request.get('area/queryProvince')

/**
* 查询城市
*/
export const getAreaByParent = (id) =>
  request.get(`area/queryByParent?parent_id=${id}`)

/**
* 房屋编号
*/
export const getDataWithSort = (id, dataForm) =>
  request.post(`form/queryAssetDataWithSort?asset_id=${id}`, dataForm)

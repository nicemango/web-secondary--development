import React, { Component } from "react";
import { Button, Divider, Tabs } from "antd";
import Collection from './components/Collection.js'
import Quantities from './components/Quantities.js'
import Settlement from './components/Settlement.js'
import Upload1 from './components/Upload.js'
import Payment from './components/Payment.js'
import "./app.less";
const { TabPane } = Tabs;


export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = { pro: false };
  }
  goToStudy = () => {
    window.open(this.props.url);

  };
  componentDidMount() {

  }
  onChange(key) {
    if (key == 3) {
      this.setState({ pro: true })
    } else {
      this.setState({ pro: false })
    }
  };

  render() {
    const { title, desc, imgUrl } = this.props;
    const { pro } = this.state
    return (
      <div className='tabs'>


        <Tabs defaultActiveKey="1" onChange={(key) => { this.onChange(key) }}>
          <TabPane tab="被征收人信息" key="1">
            <Collection />
          </TabPane>
          <TabPane tab="装修及附属工程量" key="2">
            <Quantities />
          </TabPane>
          <TabPane tab="结算" key="3">
            <Settlement updateSet={{ pro }} />
          </TabPane>
          <TabPane tab="上传资料" key="4">
            <Upload1 />
          </TabPane>
          <TabPane tab="打款记录" key="5">
            <Payment />
          </TabPane>
        </Tabs>
      </div >
    );
  }
}
